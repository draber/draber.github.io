# 📦 Spelling Bee Assistant 5.2.1
**Release Date:** 02 February 2026  

## Bug Fix
- Changes on NYT website cause app to fail
