# 📦 Spelling Bee Assistant 5.2.0
**Release Date:** 18 November 2025  

## Feature release 
- Grid now updates while open