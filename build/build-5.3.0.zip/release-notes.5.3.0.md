# 📦 Spelling Bee Assistant 5.3.0
**Release Date:** 05 February 2026  

## New Feature
- 1st letter and First 2 letters are now mutually exclusive

## Bug Fix
- Fixes remaining issues from https://github.com/draber/draber.github.io/issues/185
