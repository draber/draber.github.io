# 📦 Spelling Bee Assistant 5.1.1
**Release Date:** 18 June 2025  

## Maintenance release 
- Fixes inconsistencies regarding the activation of dark mode
- Fixes focus issues introduces by latest NYT update
- Fixes unwanted toggling of word list when selecting "Spill the beans"